#ifndef apio_included
#define apio_included
#include <input.h>
struct output{
	int pin;
	int valore;
};
typedef struct output Output;

struct input{
	int pin;
	int valore;
};
typedef struct input Input;
Output * onoff(Output * ventilatore, String valore){
	
/*c code for onoff to be copied verbatim */
if (valore.toInt())==0){
ventilatore[0].valore=255;
analogWrite(ventilatore[0].pin,ventilatore[0].valore);
} else {
ventilatore[0].valore=0;
analogWrite(ventilatore[0].pin,ventilatore[0].valore);
}

	return ventilatore;
}Output * velocita(Output * ventilatore, String valore){
	
/*c code for velocita to be copied verbatim */
if (valore.toInt())==1){
ventilatore[1].valore=0;
analogWrite(ventilatore[1].pin,ventilatore[1].valore);
} else {
ventilatore[1].valore=255;
analogWrite(ventilatore[1].pin,ventilatore[1].valore);
}

	return ventilatore;
}
#endif